window.onload = function(){
	console.log("WebApp running!");
}